import xbmc
import xbmcaddon
import xbmcgui
import os
import xbmcvfs
import time
from resources.lib.modules.backtothefuture import PY2
from resources.lib.modules import maintenance

# Code to map the old translatePath
if PY2:
    translatePath = xbmc.translatePath
    loglevel = xbmc.LOGNOTICE
else:
    translatePath = xbmcvfs.translatePath
    loglevel = xbmc.LOGINFO

AddonID = "script.ezmaintenanceplusplus"
packagesdir = translatePath(os.path.join("special://home/addons/packages", ""))
thumbnails = translatePath("special://home/userdata/Thumbnails")
dialog = xbmcgui.Dialog()
setting = xbmcaddon.Addon().getSetting
iconpath = translatePath(os.path.join("special://home/addons/" + AddonID, "icon.png"))
# if setting('autoclean') == 'true':
# control.clearCache()

notify_mode = setting("notify_mode")
auto_clean = setting("startup.cache")
filesize = int(setting("filesize_alert"))
filesize_thumb = int(setting("filesizethumb_alert"))
maxpackage_zips = int(setting("packagenumbers_alert"))

total_size2 = 0
total_size = 0
count = 0

for dirpath, dirnames, filenames in os.walk(packagesdir):
    count = 0
    for f in filenames:
        count += 1
        fp = os.path.join(dirpath, f)
        total_size += os.path.getsize(fp)
total_sizetext = "%.0f" % (total_size / 1024000.0)

if int(total_sizetext) > filesize:
    choice2 = xbmcgui.Dialog().yesno(
        "[COLOR=red]Autocleaner[/COLOR]",
        "The packages folder is [COLOR red]"
        + str(total_sizetext)
        + " MB [/COLOR] - [COLOR red]"
        + str(count)
        + "[/COLOR] zip files"
        + "\n"
        + "The folder can be cleaned up without issues to save space..."
        + "\n"
        + "Do you want to clean it now?",
        yeslabel="Yes",
        nolabel="No",
    )
    if choice2 == 1:
        maintenance.purgePackages()

for dirpath2, dirnames2, filenames2 in os.walk(thumbnails):
    for f2 in filenames2:
        fp2 = os.path.join(dirpath2, f2)
        total_size2 += os.path.getsize(fp2)
total_sizetext2 = "%.0f" % (total_size2 / 1024000.0)

if int(total_sizetext2) > filesize_thumb:
    choice2 = xbmcgui.Dialog().yesno(
        "[COLOR=red]Autocleaner[/COLOR]",
        "The images folder is [COLOR red]"
        + str(total_sizetext2)
        + " MB   [/COLOR]"
        + "\n"
        + "The folder can be cleaned up without issues to save space..."
        + "\n"
        + "Do you want to clean it now?",
        yeslabel="Yes",
        nolabel="No",
    )
    if choice2 == 1:
        maintenance.deleteThumbnails()

total_sizetext = "%.0f" % (total_size / 1024000.0)
total_sizetext2 = "%.0f" % (total_size2 / 1024000.0)

if notify_mode == "true":
    xbmc.executebuiltin(
        "Notification(%s, %s, %s, %s)"
        % (
            "Maintenance Status",
            "Packages: " + str(total_sizetext) + " MB"
            " - Images: " + str(total_sizetext2) + " MB",
            "5000",
            iconpath,
        )
    )
time.sleep(3)
if auto_clean == "true":
    maintenance.clearCache()

maintenance.logMaintenance("Service started")


class Monitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        maintenance.logMaintenance("Monitor init")
        maintenance.determineNextMaintenance()

    def onSettingsChanged(self):
        maintenance.logMaintenance("onSettingsChanged")
        maintenance.determineNextMaintenance()


def _wait_kodi_ready(monitor, timeout=120):
    """Block (interruptibly) until Kodi's GUI is actually up, so we never prompt on a black
    boot screen. Returns False on abort; True once the home window is visible OR the bound
    is reached (well past any black-screen phase). Never raises."""
    waited = 0
    while waited < timeout:
        if monitor.abortRequested():
            return False
        try:
            if xbmc.getCondVisibility("Window.IsVisible(home)"):
                return True
        except Exception:
            pass
        if monitor.waitForAbort(2):
            return False
        waited += 2
    return True


def _maybe_prompt_after_restore(monitor):
    """On the FIRST boot after a restore, run the post-restore tune-up: offer to rename THIS
    device and to retune the video cache buffer for it (a restore cloned the source box's name
    and buffer size). Fully guarded: nothing here may block or crash the boot service. The marker
    check happens BEFORE _wait_kodi_ready, so a normal boot (no marker) returns immediately and
    never delays the maintenance loop; only a genuinely pending restore waits for the GUI."""
    try:
        from resources.lib.modules import tools
    except Exception:
        return
    try:
        if not tools.buffer_prompt_pending():
            return
    except Exception:
        return
    try:
        if not _wait_kodi_ready(monitor):
            return
        tools.prompt_after_restore()
    except Exception:
        pass


if __name__ == "__main__":
    monitor = Monitor()

    _maybe_prompt_after_restore(monitor)

    while not monitor.abortRequested():
        # Sleep/wait for abort for 10 seconds
        if monitor.waitForAbort(10):
            # Abort was requested while waiting. We should exit
            break
        maintenance.logMaintenance("monitor loop")
        if not xbmc.Player().isPlayingVideo():
            nextMaintenance = maintenance.getNextMaintenance()
            maintenance.logMaintenance(
                "time.time() = %s, nextMaintenance = %s"
                % (str(time.time()), str(nextMaintenance))
            )
            if nextMaintenance > 0 and time.time() >= nextMaintenance:
                xbmc.log("ezmaintenanceplus: AutoClean started", level=loglevel)
                maintenance.clearCache()
                xbmc.log("ezmaintenanceplus: AutoClean done", level=loglevel)
                maintenance.determineNextMaintenance()
                # xbmc.executebuiltin('Notification(%s, %s, %s, %s)' % ('EZ Maintenance++' , 'Clean Completed' , '3000', iconpath))

    del monitor
